Legend TV Parts Vault 5.2.0 — Cloud AI Workspace

Android build: gradle assembleDebug
Version name: 5.2.0
Version code: 31
Application ID: com.legendtvparts.repairvault
Existing local database key is preserved: legendTvPartsVault_v3_clean

BACK UP FIRST
Open Backup & Export and export a full JSON backup before installing. Do not uninstall 5.1.0.

CLOUD AI SETUP (optional)
1. Deploy cloudflare-worker/worker.js as a Cloudflare Worker.
2. In Worker Settings → Variables and Secrets, add GEMINI_API_KEY as a SECRET. Never put this key in GitHub, app code, or the app's endpoint field.
3. Optionally set ALLOWED_ORIGIN to your hosted app origin. The APK uses file:// origin, so the Worker template defaults to "*" to allow WebView requests; protect usage with Cloudflare rate limiting and/or access controls before public release.
4. Copy the Worker HTTPS URL into AI Repair Assistant → Secure AI backend URL. The URL is not a secret.
5. Test text diagnosis first, then test a non-sensitive photo.
6. If the service is unavailable or not configured, use Generate guided checks (offline).

Security/privacy
Cloud AI sends model, symptom, observations and the selected photo to your Worker and Google's Gemini API when you tap Run cloud AI diagnosis. Do not submit customer personal data. The API key remains server-side. The included Worker intentionally returns generic errors and does not log request bodies. Configure rate limits, usage budgets and allowed access before public deployment.

Compatibility data
The evidence explorer searches records already saved on your device. No unsupported model/board matches are seeded as facts. Add exact part/revision and source/manual evidence to the compatibility records, and mark results verified only after testing the exact revision.

Validation status
The source archive was updated. A successful GitHub Actions build and an on-device regression test are still required before calling this release verified.
