LEGEND TV PARTS REPAIR VAULT — ANDROID PROJECT
==========================================

What this is
------------
This is the Android source project wrapping the existing offline TV Repair
Knowledge Vault in a native Android WebView shell. The app name on the device
is "Legend TV Parts Vault". The app stores entries in WebView local storage on that
device. It does not require an account or a server.

Important limitation
--------------------
This package is Android source code, not a precompiled APK. This workspace
does not have the Android SDK/Gradle toolchain installed, so it cannot truthfully
provide a tested installable APK from here. The included GitHub Actions workflow
can build a debug APK in the cloud after the project is uploaded to a GitHub
repository.

Build using a computer
----------------------
1. Install Android Studio.
2. Open this project folder.
3. Allow Gradle sync to complete.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk

Build from a phone using GitHub Actions
---------------------------------------
1. Sign in to GitHub in your phone browser and create a NEW private repository.
2. Upload the contents of this ZIP into the repository (the files/folders inside
   the project folder, not the outer folder itself).
3. Open the repository's Actions tab and enable Actions if asked.
4. Select "Build Android APK" from the workflow list.
5. Tap "Run workflow".
6. When the run finishes successfully, open it and download the artifact named
   "tv-repair-vault-debug-apk". Unzip the artifact to get app-debug.apk.
7. Open the APK on Android and approve installation from that source if Android
   asks. Only install APKs you built yourself or trust.

For the web-only version
------------------------
The original standalone HTML version can also be used directly without compiling
Android code. It is included at:
app/src/main/assets/tv_repair_knowledge_vault_offline.html

Data and privacy
----------------
- No analytics, advertising SDK, or network permission is included.
- The app uses local browser/WebView storage. Export backups from inside the app
  regularly. Clearing app data or uninstalling can remove locally stored records.
- This is a debug build workflow, not a Play Store release pipeline. A Play Store
  release needs signing, policy checks, privacy disclosures, and testing.

Version: 1.0.0
