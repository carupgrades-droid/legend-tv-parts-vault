package com.legendtvparts.repairvault;

import android.app.Activity;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import java.io.File;
import java.io.IOException;
import androidx.core.content.FileProvider;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 2401;
    private static final int CAMERA_REQUEST = 2402;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri pendingCameraUri;
    private TextRecognizer textRecognizer;
    private BarcodeScanner barcodeScanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        barcodeScanner = BarcodeScanning.getClient();

        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new OcrBridge(), "AndroidOCR");
        webView.addJavascriptInterface(new BarcodeBridge(), "AndroidBarcode");
        webView.addJavascriptInterface(new ExternalBridge(), "AndroidExternal");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    if (params.isCaptureEnabled()) {
                        launchCameraCapture();
                    } else {
                        Intent intent = params.createIntent();
                        startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    }
                } catch (Exception e) {
                    if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/tv_repair_knowledge_vault_offline.html");
    }


    private void launchCameraCapture() throws IOException {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (camera.resolveActivity(getPackageManager()) == null) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = null;
            return;
        }
        File imageFile = new File(getCacheDir(), "vault_camera_" + System.currentTimeMillis() + ".jpg");
        pendingCameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", imageFile);
        camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
        camera.setClipData(ClipData.newRawUri("Vault camera photo", pendingCameraUri));
        camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(camera, CAMERA_REQUEST);
    }

    private class ExternalBridge {
        @JavascriptInterface
        public void openUrl(String value) {
            try {
                Uri uri = Uri.parse(value);
                if (!"https".equalsIgnoreCase(uri.getScheme())) return;
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            } catch (Exception ignored) { }
        }
    }

    private class OcrBridge {
        @JavascriptInterface
        public void recognizeLabel(String dataUrl, String requestId) {
            try {
                int comma = dataUrl.indexOf(',');
                String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) { sendOcrResult(requestId, "", "Could not decode image"); return; }
                InputImage image = InputImage.fromBitmap(bitmap, 0);
                textRecognizer.process(image)
                    .addOnSuccessListener(result -> sendOcrResult(requestId, result.getText(), null))
                    .addOnFailureListener(error -> sendOcrResult(requestId, "", "Text recognition failed"));
            } catch (Exception error) {
                sendOcrResult(requestId, "", "Image processing failed");
            }
        }
    }

    private class BarcodeBridge {
        @JavascriptInterface
        public void scanImage(String dataUrl, String requestId) {
            try {
                int comma = dataUrl.indexOf(',');
                String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) { sendBarcodeResult(requestId, "", "Could not decode image"); return; }
                InputImage image = InputImage.fromBitmap(bitmap, 0);
                barcodeScanner.process(image)
                    .addOnSuccessListener(results -> {
                        String value = results.isEmpty() ? "" : results.get(0).getRawValue();
                        sendBarcodeResult(requestId, value, results.isEmpty() ? "No barcode or QR code detected" : null);
                    })
                    .addOnFailureListener(error -> sendBarcodeResult(requestId, "", "Barcode scanning failed"));
            } catch (Exception error) {
                sendBarcodeResult(requestId, "", "Image processing failed");
            }
        }
    }

    private void sendBarcodeResult(String requestId, String value, String error) {
        if (webView == null) return;
        String id = org.json.JSONObject.quote(requestId == null ? "" : requestId);
        String body = org.json.JSONObject.quote(value == null ? "" : value);
        String err = error == null ? "null" : org.json.JSONObject.quote(error);
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "window.handleBarcodeResult(" + id + "," + body + "," + err + ")", null);
        });
    }

    private void sendOcrResult(String requestId, String text, String error) {
        if (webView == null) return;
        String id = org.json.JSONObject.quote(requestId == null ? "" : requestId);
        String body = org.json.JSONObject.quote(text == null ? "" : text);
        String err = error == null ? "null" : org.json.JSONObject.quote(error);
        runOnUiThread(() -> {
            if (webView != null) {
                String callback;
                if (requestId != null && requestId.startsWith("repair_")) callback = "window.handleRepairOcrResult";
                else if (requestId != null && requestId.startsWith("quicklookup_")) callback = "window.handleQuickLookupOcrResult";
                else callback = "window.handleOcrResult";
                webView.evaluateJavascript(
                    callback + "(" + id + "," + body + "," + err + ")", null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && filePathCallback != null) {
            Uri[] results = resultCode == RESULT_OK && pendingCameraUri != null
                    ? new Uri[]{pendingCameraUri} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            pendingCameraUri = null;
        } else if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidOCR");
            webView.removeJavascriptInterface("AndroidBarcode");
            webView.removeJavascriptInterface("AndroidExternal");
            webView.destroy();
            webView = null;
        }
        if (textRecognizer != null) {
            textRecognizer.close();
            textRecognizer = null;
        }
        if (barcodeScanner != null) { barcodeScanner.close(); barcodeScanner = null; }
        super.onDestroy();
    }
}
