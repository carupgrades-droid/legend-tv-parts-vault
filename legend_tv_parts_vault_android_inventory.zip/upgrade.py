from pathlib import Path
import re
root=Path('/mnt/data/v1_7_1_work')
html_path=root/'app/src/main/assets/tv_repair_knowledge_vault_offline.html'
html=html_path.read_text()
lines=html.splitlines()
# Extract the repair-capture layout block from the Dashboard, keeping the original markup intact.
start=next(i for i,l in enumerate(lines) if l.strip()=='<div class="layout">' and i>70 and i<120)
end=next(i for i in range(start, len(lines)) if lines[i].strip()=='</div>' and i>start and i<120 and lines[i+1].strip().startswith('<div class="panel" style="margin-top:14px"'))
capture_block='\n'.join(lines[start:end+1])
# Remove it from dashboard.
del lines[start:end+1]
html='\n'.join(lines)+'\n'
# Add dedicated navigation button immediately after Dashboard.
old='<button class="active" data-tab="capture"><span class="nav-icon">⌂</span>Dashboard</button><button data-tab="parts">'
new='<button class="active" data-tab="capture"><span class="nav-icon">⌂</span>Dashboard</button><button data-tab="captureKnowledge"><span class="nav-icon">✎</span>Capture Knowledge</button><button data-tab="parts">'
assert old in html
html=html.replace(old,new,1)
# Add capture and sale shortcuts to the dashboard quick actions.
old='''<button class="quick-action" type="button" data-jump="parts" data-focus="partName"><span class="qa-icon">＋</span><b>Add / Edit Part</b><span>Open inventory form</span></button>'''
new='''<button class="quick-action" type="button" data-jump="captureKnowledge" data-focus="title"><span class="qa-icon">✎</span><b>Capture Repair</b><span>Save a new repair finding</span></button>
<button class="quick-action" type="button" data-jump="parts" data-focus="salePart"><span class="qa-icon">＄</span><b>Record a Sale</b><span>Log sale and reduce stock</span></button>
<button class="quick-action" type="button" data-jump="parts" data-focus="partName"><span class="qa-icon">＋</span><b>Add / Edit Part</b><span>Open inventory form</span></button>'''
assert old in html
html=html.replace(old,new,1)
# Add a compact stock snapshot on the dashboard, with fresh metrics wired into JS.
anchor='''</div></div>
<div class="panel" style="margin-top:14px"><h2>Business snapshot</h2>'''
replacement='''</div></div>
<div class="panel" style="margin-bottom:14px"><h2>Inventory pulse</h2><p class="muted small">A quick view of the stock currently saved on this device.</p><div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="stat"><b id="dashPartTypes">0</b><span>Part types</span></div><div class="stat"><b id="dashStockUnits">0</b><span>Units in stock</span></div><div class="stat"><b id="dashStockCost">$0.00</b><span>Stock cost value</span></div><div class="stat"><b id="dashLowStock">0</b><span>Low / out of stock</span></div></div><div class="actions"><button type="button" class="secondary" data-jump="parts" data-focus="partFilter">Review stock levels</button><button type="button" class="secondary" data-jump="compat" data-focus="compatSearch">Find compatible parts</button></div></div>
<div class="panel" style="margin-top:14px"><h2>Business snapshot</h2>'''
if anchor not in html:
    anchor='</div></div>\n\n<div class="panel" style="margin-top:14px"><h2>Business snapshot</h2>'
    replacement=replacement.replace('</div></div>\n<div class="panel" style="margin-top:14px"><h2>Business snapshot</h2>','</div></div>\n\n<div class="panel" style="margin-top:14px"><h2>Business snapshot</h2>')
assert anchor in html
html=html.replace(anchor,replacement,1)
# Version bump display text.
html=html.replace('VERSION 1.7.0','VERSION 1.8.0').replace('V1.7.0','V1.8.0')
html=html.replace('Legend TV Parts Repair Vault · Offline edition · Version 1.7.0 ·','Legend TV Parts Repair Vault · Offline edition · Version 1.8.0 ·')
# Insert the captured layout as its own section before the knowledge library.
marker='\n<section id="library" class="section">'
assert marker in html
new_section='''
<section id="captureKnowledge" class="section">
<div class="quickstart"><div class="quickstart-head"><div><div class="hero-kicker">REPAIR KNOWLEDGE WORKSPACE</div><h2>Capture repair knowledge</h2><p>Record symptoms, measurements, fault codes, and proven fixes. Entries remain saved locally on this device.</p></div><span class="version-pill">V1.8.0</span></div></div>
'''+capture_block+'''\n</section>
'''
html=html.replace(marker,'\n'+new_section+marker,1)
# Keep tab switching, but refresh capture stats when its dedicated screen opens.
old='function switchTab(tab){document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===tab));document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));if(tab==="library"){refreshList();refreshBrandOptions()}if(tab==="manual")renderChapters();if(tab==="parts")renderParts();if(tab==="compat"){refreshCompatPartOptions();renderCompat()}window.scrollTo({top:0,behavior:"smooth"})}'
new='function switchTab(tab){document.querySelectorAll(".section").forEach(s=>s.classList.toggle("active",s.id===tab));document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));if(tab==="captureKnowledge")refreshStats();if(tab==="library"){refreshList();refreshBrandOptions()}if(tab==="manual")renderChapters();if(tab==="parts")renderParts();if(tab==="compat"){refreshCompatPartOptions();renderCompat()}window.scrollTo({top:0,behavior:"smooth"})}'
assert old in html
html=html.replace(old,new,1)
# Extend business dashboard refresh to update the new dashboard stock metrics.
old_func='''function refreshBusinessDashboard(){const sales=Array.isArray(state.sales)?state.sales:[],movements=Array.isArray(state.stockMovements)?state.stockMovements:[];const revenue=sales.reduce((a,x)=>a+(Number(x.revenue)||0),0),profit=sales.reduce((a,x)=>a+(Number(x.profit)||0),0),units=sales.reduce((a,x)=>a+(Number(x.qty)||0),0);if($("bizSales"))$("bizSales").textContent=money(revenue);if($("bizProfit"))$("bizProfit").textContent=money(profit);if($("bizOrders"))$("bizOrders").textContent=sales.length;if($("bizUnits"))$("bizUnits").textContent=units;if($("bizLowStock"))$("bizLowStock").textContent=(state.parts||[]).filter(p=>(Number(p.qty)||0)<=(Number(p.reorder)||0)).length;if($("recentActivity")){'''
new_func='''function refreshBusinessDashboard(){const sales=Array.isArray(state.sales)?state.sales:[],movements=Array.isArray(state.stockMovements)?state.stockMovements:[],parts=Array.isArray(state.parts)?state.parts:[];const revenue=sales.reduce((a,x)=>a+(Number(x.revenue)||0),0),profit=sales.reduce((a,x)=>a+(Number(x.profit)||0),0),units=sales.reduce((a,x)=>a+(Number(x.qty)||0),0),lowStock=parts.filter(p=>(Number(p.qty)||0)<=(Number(p.reorder)||0)).length,stockUnits=parts.reduce((a,p)=>a+(Number(p.qty)||0),0),stockCost=parts.reduce((a,p)=>a+(Number(p.qty)||0)*(Number(p.cost)||0),0);if($("bizSales"))$("bizSales").textContent=money(revenue);if($("bizProfit"))$("bizProfit").textContent=money(profit);if($("bizOrders"))$("bizOrders").textContent=sales.length;if($("bizUnits"))$("bizUnits").textContent=units;if($("bizLowStock"))$("bizLowStock").textContent=lowStock;if($("dashPartTypes"))$("dashPartTypes").textContent=parts.length;if($("dashStockUnits"))$("dashStockUnits").textContent=stockUnits;if($("dashStockCost"))$("dashStockCost").textContent=money(stockCost);if($("dashLowStock"))$("dashLowStock").textContent=lowStock;if($("recentActivity")){'''
assert old_func in html
html=html.replace(old_func,new_func,1)
html_path.write_text(html)
# Mirror JS changes into the standalone root JS source where applicable.
js_path=root/'app.js'
js=js_path.read_text()
assert old in js
js=js.replace(old,new,1)
assert old_func in js
js=js.replace(old_func,new_func,1)
js_path.write_text(js)
# Version metadata and project notes.
gradle=root/'app/build.gradle'
g=gradle.read_text().replace("versionCode 9","versionCode 10").replace("versionName '1.7.0'","versionName '1.8.0'")
gradle.write_text(g)
readme=root/'README-ANDROID.txt'
r=readme.read_text()
r += '''\n\nUPGRADE 1.8.0 NOTES\n- Moves Capture Repair Knowledge to its own dedicated navigation button and screen; it is no longer embedded in the Dashboard.\n- Adds dashboard shortcuts for capturing a repair and recording a sale.\n- Adds an Inventory Pulse dashboard panel for part types, units in stock, stock cost value, and low/out-of-stock count.\n- Keeps existing localStorage key and saved data model unchanged.\n- Updates Android versionCode to 10 and versionName to 1.8.0.\n- Existing GitHub Actions workflow is unchanged.\n'''
readme.write_text(r)
