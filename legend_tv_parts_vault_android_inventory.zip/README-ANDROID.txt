LEGEND TV PARTS REPAIR VAULT — ANDROID PROJECT
==========================================

What this is
------------
This is the Android source project wrapping the existing offline TV Repair
Knowledge Vault in a native Android WebView shell. The app name on the device
is "Legend TV Parts Vault". The app stores entries in WebView local storage on that
device. It does not require an account or a server.

Important limitation
--------------------
This package is Android source code, not a precompiled APK. This workspace
does not have the Android SDK/Gradle toolchain installed, so it cannot truthfully
provide a tested installable APK from here. The included GitHub Actions workflow
can build a debug APK in the cloud after the project is uploaded to a GitHub
repository.

Build using a computer
----------------------
1. Install Android Studio.
2. Open this project folder.
3. Allow Gradle sync to complete.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at:
   app/build/outputs/apk/debug/app-debug.apk

Build from a phone using GitHub Actions
---------------------------------------
1. Sign in to GitHub in your phone browser and create a NEW private repository.
2. Upload the contents of this ZIP into the repository (the files/folders inside
   the project folder, not the outer folder itself).
3. Open the repository's Actions tab and enable Actions if asked.
4. Select "Build Android APK" from the workflow list.
5. Tap "Run workflow".
6. When the run finishes successfully, open it and download the artifact named
   "tv-repair-vault-debug-apk". Unzip the artifact to get app-debug.apk.
7. Open the APK on Android and approve installation from that source if Android
   asks. Only install APKs you built yourself or trust.

For the web-only version
------------------------
The original standalone HTML version can also be used directly without compiling
Android code. It is included at:
app/src/main/assets/tv_repair_knowledge_vault_offline.html

Data and privacy
----------------
- No analytics, advertising SDK, or network permission is included.
- The app uses local browser/WebView storage. Export backups from inside the app
  regularly. Clearing app data or uninstalling can remove locally stored records.
- This is a debug build workflow, not a Play Store release pipeline. A Play Store
  release needs signing, policy checks, privacy disclosures, and testing.

Current source version: 4.0.0 (Android versionName 4.0.0, versionCode 19)

UPGRADE 1.1.0 NOTES
- Uses a new local storage key (legendTvPartsVault_v3_clean) so the updated app starts with a clean workspace. Data under the old v2 key is not migrated or erased by this version.
- Adds stock cost value, potential sales value, and potential gross profit calculations.
- Adds manual market price and last-checked date fields.
- Adds compressed inventory photo attachments and experimental coarse visual similarity search against stored photos.
- Adds cross-compatible part records with model, alternate/original part number, relationship, evidence notes, and explicit verification status.
- Adds WebView file chooser handling for image selection and JSON backup restore.
- Visual photo matching is approximate only. OCR-based label reading is not included in this build; enter printed part numbers manually and verify compatibility against service information.


Version 1.2.0 upgrade notes
- Keeps the same localStorage database key so existing inventory can remain when updating the installed app. Back up before upgrading.
- Part cards can be tapped or edited with the Edit button; each card shows unit profit, margin, and total in-stock profit.
- Inventory supports multiple compressed part photos, market price and checked date, stock adjustment, and CSV export.
- Cross-compatible part links connect one inventory item to TV brands/models and alternate numbers; compatibility data is user-entered and must be verified.
- Adds bundled on-device ML Kit text recognition for label photos. OCR suggestions must be reviewed because characters can be misread; it does not verify compatibility.
- OCR image and text processing occurs locally on the device; no OCR service upload is used.

UPGRADE 1.4.0 NOTES
- Adds ML Kit barcode/QR scanning from a camera/gallery photo. Scanned values are searched against saved barcode values, SKUs, and part records; scanning does not identify external parts automatically.
- Adds TV model lookup against saved part model fields and user-entered cross-compatibility links. Verification status is displayed and compatibility must still be checked against reliable service information.
- Adds dedicated barcode/QR and shelf/bin location fields to inventory; both are included in CSV export and catalog PDF.
- Adds a printable catalog PDF export generated on-device, plus expanded spreadsheet CSV export.
- Improves JSON backup restore so part links are remapped correctly and inventory/compatibility views refresh after import. Full backup includes notes, inventory, photos, chapters, and compatibility links.
- Existing on-device storage key remains unchanged to preserve existing data. Export a JSON backup before installing/upgrading. APK build has not been executed in this workspace; use the included GitHub Actions workflow to compile and test the build.

Version 1.4.0 visible dashboard improvements: six shortcut tiles for add/edit part, part photos, OCR label scan, TV compatibility, market price tracking, and backup/export. App version is displayed in the header and footer.


UPGRADE 1.5.1 NOTES
- OCR recognized text is editable before applying it to the part number or notes. Editing the recognized text refreshes the suggested-part-number and add-to-notes controls.
- Updated the interface to a premium navy-and-gold theme with clearer focus states, stronger panel contrast, refined buttons, and more consistent visual hierarchy.
- Keeps the existing local storage key and inventory/backup data structure so installed data is preserved during an in-place upgrade. Export a JSON backup before upgrading as a precaution.
- Android versionCode 7 / versionName 1.7.0.


Version 1.7.0 feature update: editable OCR candidate preview, removable saved part photos, editable compatibility links, and market-price history tracking (up to 30 entries per part). Existing local-storage database key is unchanged.


UPGRADE 1.7.0 NOTES
- Fixes navigation layout by placing dashboard statistics and shortcut actions inside the Dashboard screen.
- Dashboard, Inventory, Compatibility, Repair Library, Manuals, and Backup & Export now display as separate screens through the existing navigation buttons.
- Updates Android versionCode to 8 and versionName to 1.7.0.
- Keeps the existing local-storage key, data structure, app features, and GitHub Actions workflow unchanged.


UPGRADE 1.8.0 NOTES
- Moves Capture Repair Knowledge to its own dedicated navigation button and screen; it is no longer embedded in the Dashboard.
- Adds dashboard shortcuts for capturing a repair and recording a sale.
- Adds an Inventory Pulse dashboard panel for part types, units in stock, stock cost value, and low/out-of-stock count.
- Keeps existing localStorage key and saved data model unchanged.
- Updates Android versionCode to 10 and versionName to 1.8.0.
- Existing GitHub Actions workflow is unchanged.


UPGRADE 1.9.0 NOTES
- Adds a dedicated Quick Lookup navigation screen and dashboard shortcut.
- Searches saved inventory fields (part number, barcode/SKU, model, shelf/bin, supplier, and notes), compatibility links with their saved verification status, and repair knowledge notes in one place.
- Search results can open/edit the matching inventory part or repair entry.
- Results are local-only; the app does not query an external TV database or assert unrecorded compatibility.
- Keeps the existing localStorage database key and saved-data structures unchanged.
- Updates Android versionCode to 11 and versionName to 1.9.0.
- GitHub Actions workflow remains unchanged.


UPGRADE 2.0.0 NOTES
- Adds a dedicated Part Detail screen with saved photos, identifiers, stock and reorder status, pricing, compatibility evidence, notes, and recent stock movements.
- Inventory cards and text lookup results can open Part Detail; detail view links to edit and sale workflows.
- Adds Search by photo to Quick Lookup, comparing an uploaded/captured image against saved inventory photos.
- Improves photo match ranking and clearly labels similarity as approximate, not AI part identification or compatibility verification.
- Keeps existing localStorage key and record schema; no migration or data reset is introduced.
- Updates Android versionCode to 12 and versionName to 2.0.0.
- GitHub Actions workflow remains unchanged.



Version 2.1.0 upgrade notes
- Adds a dedicated Repair Search workspace with photo selection, on-device OCR using the existing ML Kit bridge, editable OCR text, targeted web searches for manuals/schematics, board repair discussions, YouTube walkthroughs, component datasheets, replacement listings, and diagnostic measurements.
- Adds a Google Lens launch action. Android may not pass the selected photo directly into Lens; if it does not, select the same photo from the phone in Lens.
- Adds local search across saved inventory and repair notes, plus a workflow to create a repair-note draft for review before saving.
- Web search results are external and are not automatically verified or scraped into inventory. Review all extracted identifiers and verify exact board revision and compatibility.
- Preserves local storage key legendTvPartsVault_v3_clean and the existing GitHub Actions build workflow.


VERSION 2.2.0 UPGRADE NOTES
- Adds a local Repair Casebook to track investigations over time.
- Cases save board/model/component identifiers, symptoms, measurements, corrected OCR text, findings, source URLs, and status.
- Cases can be searched, reopened, updated, or deleted. Case data is included in JSON backups.
- The casebook does not save photo files inside each case; keep original photos in the phone's photo library to limit local storage use.
- Existing local storage key and GitHub Actions workflow are unchanged.


UPGRADE 2.3.0 NOTES
- Adds an explicit Open camera action in Quick Lookup and native Android camera capture support through FileProvider.
- Adds a separate gallery image picker.
- Adds on-device OCR to Quick Lookup photos and an editable recognized-text field.
- Adds targeted web research links for part identifiers, service manuals/schematics, repair discussions, replacement pricing, and datasheets.
- Adds Google Lens launch and part-specific research actions. Lens may require selecting the image again.
- Existing localStorage key, data model, and GitHub Actions workflow are unchanged.
- Version code 15 and version name 2.3.0.


UPGRADE 2.4.0 NOTES
- Adds camera and gallery photo attachments to Capture Repair Knowledge entries.
- Repair photos are compressed, shown as thumbnails, editable/removable from the saved entry, and included in JSON backups.
- A photo used in Repair Search can be carried into the repair-note draft before saving.
- Allows up to four photos per repair entry to help manage local browser storage.
- Android versionCode 16 / versionName 2.4.0.
- Existing GitHub Actions workflow and localStorage database key are unchanged.


UPGRADE 2.5.0 NOTES
- Makes camera and gallery photo attachment actions clearer and easier to tap in Capture Repair Knowledge.
- Open Camera takes a new repair photo; Choose Photos selects existing gallery images (multiple allowed).
- Existing photo compression, previews, local saving, and JSON backup behavior are retained.
- Android versionCode 17, versionName 2.5.0.
- GitHub Actions workflow unchanged.


VERSION 3.0.0 CONSOLIDATED UPGRADE
---------------------------------
- AI Repair Assist provides offline symptom-pattern hypotheses, structured next checks, related saved-case hints, and safety/confidence labels. It is a transparent local rules engine, not cloud AI or image-based damage recognition.
- Replacement-board comparison checks normalized identifiers and searches local inventory/compatibility evidence; similar numbers do not prove compatibility.
- Business insights summarize reorder needs, recorded sales velocity, and approximate stock cover from this device's recorded sales only.
- Existing localStorage key, saved data structures, repair photos, cases, inventory, sales, compatibility, and JSON backup compatibility are preserved.
- GitHub Actions workflow remains unchanged. Android versionCode 18 / versionName 3.0.0.


VERSION 4.0.0 NOTES
-------------------
See CHANGELOG-4.0.0.txt. The Advanced Repair Lab stores its new evidence and relationship records locally in a separate key so existing v3 repair data remains intact. Gemini/cloud photo diagnosis is not live in this release; configure a secure backend before enabling that capability. The endpoint setting does not contain or replace API credentials.
