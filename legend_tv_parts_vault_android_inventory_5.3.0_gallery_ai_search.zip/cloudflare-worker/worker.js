// Legend TV Parts Vault 5.2.0 Gemini proxy — deploy as a Cloudflare Worker.
// Configure secrets/vars in the Worker dashboard:
//   GEMINI_API_KEY (secret), ALLOWED_ORIGIN (exact app/site origin if hosted; for file:// WebView use "*")
// Never commit the API key. The app sends only the repair prompt and optional selected photo.
const cors = (origin, allowed) => ({
  "Access-Control-Allow-Origin": allowed === "*" ? "*" : (origin === allowed ? allowed : "null"),
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8",
  "Vary": "Origin"
});
export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const allowed = env.ALLOWED_ORIGIN || "*";
    const headers = cors(origin, allowed);
    if (request.method === "OPTIONS") return new Response(null, {status:204, headers});
    if (request.method !== "POST") return new Response(JSON.stringify({error:"Use POST."}), {status:405, headers});
    if (allowed !== "*" && origin !== allowed) return new Response(JSON.stringify({error:"Origin not allowed."}), {status:403, headers});
    if (!env.GEMINI_API_KEY) return new Response(JSON.stringify({error:"Backend Gemini API key is not configured."}), {status:503, headers});
    let body;
    try { body = await request.json(); } catch (_) { return new Response(JSON.stringify({error:"Invalid JSON."}), {status:400, headers}); }
    const model = String(body.model || "").trim().slice(0,120);
    const symptom = String(body.symptom || "").trim().slice(0,100);
    const observed = String(body.observed || "").trim().slice(0,6000);
    if (!model || !symptom || !observed) return new Response(JSON.stringify({error:"TV model, symptom, and observed facts are required."}), {status:400, headers});
    const parts = [{text:
`You are a cautious TV repair assistant for qualified technicians. Provide preliminary troubleshooting, not certainty.
TV model: ${model}
Symptom category: ${symptom}
Observed facts (user-provided; may be incomplete): ${observed}
Answer with: (1) facts vs hypotheses, (2) prioritized safe checks, (3) what result each check distinguishes, (4) parts that must NOT be ordered until confirmed, (5) missing information. Only state model-specific expected voltages or compatibility if directly supported by supplied evidence; otherwise say consult exact service manual. Never recommend bypassing safety protections. Warn that power boards can retain hazardous voltage and live testing is for qualified technicians only. Treat image labels/board numbers as OCR-like suggestions requiring physical verification.`
    }];
    const photo = body.photo;
    if (photo && typeof photo.base64 === "string" && typeof photo.mimeType === "string") {
      if (!/^image\/(jpeg|png|webp)$/i.test(photo.mimeType) || photo.base64.length > 8_000_000)
        return new Response(JSON.stringify({error:"Photo must be JPEG, PNG, or WebP and within the size limit."}), {status:400, headers});
      parts.push({inline_data:{mime_type:photo.mimeType,data:photo.base64}});
    }
    try {
      const upstream = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
        method:"POST",
        headers:{"Content-Type":"application/json","x-goog-api-key":env.GEMINI_API_KEY},
        body:JSON.stringify({contents:[{role:"user",parts}],generationConfig:{temperature:0.2,maxOutputTokens:1400}})
      });
      const result = await upstream.json();
      if (!upstream.ok) return new Response(JSON.stringify({error:"Gemini request failed. Check Worker logs and API access."}), {status:502, headers});
      const diagnosis = (result.candidates?.[0]?.content?.parts || []).map(p=>p.text || "").join("\n").trim();
      if (!diagnosis) return new Response(JSON.stringify({error:"Gemini returned no diagnosis."}), {status:502, headers});
      return new Response(JSON.stringify({diagnosis,model:"gemini-2.5-flash"}), {status:200, headers});
    } catch (_) {
      return new Response(JSON.stringify({error:"Could not reach Gemini service."}), {status:502, headers});
    }
  }
};
