LEGEND TV PARTS VAULT 5.0.0 — ANDROID BUILD NOTES

This is the Android source project for the Master Technician Edition. It is a WebView app and retains the 4.9.0 local vault storage key. New Master Technician jobs and evidence notes are stored additively in the existing local app state.

IMPORTANT: Before installing any upgrade, export the full JSON backup from Backup & Export. Keep the working 4.9.0 installed until the 5.0.0 build succeeds and you test the new APK.

Build in GitHub Actions: extract this ZIP into a clean workspace, set up JDK 17 and Gradle, and run `gradle assembleDebug`. Expected APK: `app/build/outputs/apk/debug/app-debug.apk`. Verify `app/build.gradle` has versionCode 29 and versionName 5.0.0.

Privacy and limitations: offline-first local features; optional online research opens a browser only when selected. No automatic cloud backup or cloud AI service is implemented. Export the full-vault JSON and manually upload it to a cloud provider if desired. Check that backups are readable and keep them private.

Release gate: a green GitHub Actions build and a real installation/feature test are still required.
