Legend TV Parts Vault 4.9.0 — Android/GitHub build

Project ZIP: legend_tv_parts_vault_android_inventory_4.9.0_combined.zip
Version: 4.9.0 (versionCode 28)

Build instructions for GitHub: upload this ZIP to the repository root and commit it to main. Then replace .github/workflows/build-apk.yml with the workflow included in this ZIP and commit that change. Open Actions and confirm the run checks versionName 4.9.0 and versionCode 28, then builds and uploads artifact legend-tv-parts-vault-4.9.0-combined-apk. Download the artifact ZIP, extract app-debug.apk, install and test it. Keep the working 4.8.0 APK installed/available until the new APK is verified.

This project ZIP is locally prepared; a successful GitHub Android build and device testing are not claimed by this file.
