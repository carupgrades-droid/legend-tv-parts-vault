Legend TV Parts Vault 5.1.0 — Unified Workspace

This release removes version-numbered labels from the app interface and presents the existing shop and diagnostic areas with neutral task names. Existing data storage identifiers and Android application ID are retained.

Build: gradle assembleDebug
Version name: 5.1.0
Version code: 30
Application ID: com.legendtvparts.repairvault

Before installing an update, export a JSON backup from Backup & Export. Do not uninstall the currently working app. If Android reports a package/signature conflict, stop and keep the existing installation.
